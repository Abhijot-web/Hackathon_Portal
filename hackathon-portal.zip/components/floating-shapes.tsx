export function FloatingShapes() {
  return (
    <>
      {/* Floating Geometric Shapes */}
      <div className="geometric-shape w-96 h-96 bg-cyan-500 top-10 -left-20 float-animation" />
      <div
        className="geometric-shape w-80 h-80 bg-purple-600 top-1/3 -right-20 float-animation"
        style={{ animationDelay: "1s", animationDuration: "8s" }}
      />
      <div
        className="geometric-shape w-64 h-64 bg-pink-500 bottom-20 left-1/4 float-animation"
        style={{ animationDelay: "2s", animationDuration: "7s" }}
      />
      <div
        className="geometric-shape w-72 h-72 bg-blue-500 bottom-1/4 right-1/3 float-animation"
        style={{ animationDelay: "0.5s", animationDuration: "9s" }}
      />
    </>
  )
}
