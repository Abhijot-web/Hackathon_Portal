// Local storage utilities for team data management
export interface Member {
  id: number
  member_name: string
  member_email: string
  student_id?: string
}

export interface Group {
  id: number
  group_name: string
  leader_id: number
}

export interface Project {
  id: number
  title: string
  description: string
  status: string
  group_id: number
}

export interface User {
  id: number
  email: string
  name: string
  role: string
}

// User management
export function saveUser(user: User) {
  localStorage.setItem("currentUser", JSON.stringify(user))
}

export function getCurrentUser(): User | null {
  const user = localStorage.getItem("currentUser")
  return user ? JSON.parse(user) : null
}

export function signOut() {
  localStorage.removeItem("currentUser")
}

// Team data management
export function saveTeamData(group: Group, members: Member[], project: Project) {
  const teamData = { group, members, project }
  localStorage.setItem(`team_${group.id}`, JSON.stringify(teamData))
  localStorage.setItem("currentTeamId", group.id.toString())
}

export function getTeamData(): { group: Group; members: Member[]; project: Project } | null {
  const teamId = localStorage.getItem("currentTeamId")
  if (!teamId) return null

  const data = localStorage.getItem(`team_${teamId}`)
  return data ? JSON.parse(data) : null
}
