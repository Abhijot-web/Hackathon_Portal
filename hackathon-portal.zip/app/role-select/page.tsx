import Link from "next/link"
import { FloatingShapes } from "@/components/floating-shapes"

export default function RoleSelectPage() {
  return (
    <div className="relative min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-purple-950 overflow-hidden">
      <FloatingShapes />

      <div className="relative z-10 flex min-h-screen flex-col items-center justify-center px-4 py-12">
        <div className="text-center space-y-12 max-w-6xl w-full">
          {/* Header */}
          <div className="space-y-4 animate-fade-in">
            <h1 className="text-5xl md:text-6xl font-bold gradient-text animate-scale-in">Choose Your Role</h1>
            <p className="text-lg text-slate-400 animate-slide-up" style={{ animationDelay: "0.2s" }}>
              Select how you want to participate in HackaPortal
            </p>
          </div>

          {/* Role Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pt-8">
            {/* Student Card */}
            <Link href="/signup?role=student" className="group animate-slide-up" style={{ animationDelay: "0.3s" }}>
              <div className="neumorphic-card rounded-3xl p-8 space-y-6 transition-all duration-300 hover:scale-105 glow-effect-hover h-full">
                <div
                  className="w-20 h-20 mx-auto rounded-2xl bg-gradient-to-br from-cyan-500 to-cyan-600 flex items-center justify-center glow-effect animate-bounce-in"
                  style={{ animationDelay: "0.5s" }}
                >
                  <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"
                    />
                  </svg>
                </div>

                <div className="space-y-3">
                  <h2 className="text-2xl font-bold text-white">Student</h2>
                  <p className="text-slate-400 leading-relaxed">
                    Join as a participant to build innovative projects, collaborate with peers, and compete for prizes
                  </p>
                </div>

                <div className="pt-4">
                  <div className="inline-flex items-center gap-2 text-cyan-400 font-semibold group-hover:gap-3 transition-all">
                    Get Started
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                    </svg>
                  </div>
                </div>
              </div>
            </Link>

            {/* Judge Card */}
            <Link href="/signup?role=judge" className="group animate-slide-up" style={{ animationDelay: "0.4s" }}>
              <div className="neumorphic-card rounded-3xl p-8 space-y-6 transition-all duration-300 hover:scale-105 glow-effect-hover h-full">
                <div
                  className="w-20 h-20 mx-auto rounded-2xl bg-gradient-to-br from-purple-500 to-purple-600 flex items-center justify-center glow-effect animate-bounce-in"
                  style={{ animationDelay: "0.6s" }}
                >
                  <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138z"
                    />
                  </svg>
                </div>

                <div className="space-y-3">
                  <h2 className="text-2xl font-bold text-white">Judge</h2>
                  <p className="text-slate-400 leading-relaxed">
                    Evaluate projects, provide feedback, and help identify the most innovative solutions
                  </p>
                </div>

                <div className="pt-4">
                  <div className="inline-flex items-center gap-2 text-purple-400 font-semibold group-hover:gap-3 transition-all">
                    Get Started
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                    </svg>
                  </div>
                </div>
              </div>
            </Link>

            {/* Mentor Card */}
            <Link href="/signup?role=mentor" className="group animate-slide-up" style={{ animationDelay: "0.5s" }}>
              <div className="neumorphic-card rounded-3xl p-8 space-y-6 transition-all duration-300 hover:scale-105 glow-effect-hover h-full">
                <div
                  className="w-20 h-20 mx-auto rounded-2xl bg-gradient-to-br from-pink-500 to-pink-600 flex items-center justify-center glow-effect animate-bounce-in"
                  style={{ animationDelay: "0.7s" }}
                >
                  <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"
                    />
                  </svg>
                </div>

                <div className="space-y-3">
                  <h2 className="text-2xl font-bold text-white">Mentor</h2>
                  <p className="text-slate-400 leading-relaxed">
                    Guide teams with your expertise, share knowledge, and help shape the next generation of innovators
                  </p>
                </div>

                <div className="pt-4">
                  <div className="inline-flex items-center gap-2 text-pink-400 font-semibold group-hover:gap-3 transition-all">
                    Get Started
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                    </svg>
                  </div>
                </div>
              </div>
            </Link>
          </div>

          {/* Already have account */}
          <div className="pt-8 animate-fade-in" style={{ animationDelay: "0.8s" }}>
            <p className="text-slate-400">
              Already have an account?{" "}
              <Link href="/signin" className="text-cyan-400 hover:text-cyan-300 font-semibold transition-colors">
                Sign In
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
