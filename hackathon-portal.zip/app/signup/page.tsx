"use client"

import type React from "react"

import { useState, Suspense } from "react"
import { useSearchParams, useRouter } from "next/navigation"
import Link from "next/link"
import { FloatingShapes } from "@/components/floating-shapes"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { saveUser } from "@/lib/storage"

function SignUpForm() {
  const searchParams = useSearchParams()
  const router = useRouter()
  const role = searchParams.get("role") || "student"

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
  })
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [isLoading, setIsLoading] = useState(false)

  const validateEmail = (email: string) => {
    switch (role) {
      case "student":
        return email.endsWith("@nctorontostudents.ca")
      case "mentor":
        return email.endsWith("@niagaracollegetoronto.ca")
      case "judge":
        return email.includes("@") && email.includes(".")
      default:
        return false
    }
  }

  const getEmailErrorMessage = () => {
    switch (role) {
      case "student":
        return "Email must be @nctorontostudents.ca"
      case "mentor":
        return "Email must be @niagaracollegetoronto.ca"
      case "judge":
        return "Please enter a valid email address"
      default:
        return "Invalid email"
    }
  }

  const getEmailPlaceholder = () => {
    switch (role) {
      case "student":
        return "yourname@nctorontostudents.ca"
      case "mentor":
        return "yourname@niagaracollegetoronto.ca"
      case "judge":
        return "yourname@example.com"
      default:
        return "your.email@example.com"
    }
  }

  const getEmailHelperText = () => {
    switch (role) {
      case "student":
        return "Must use @nctorontostudents.ca email"
      case "mentor":
        return "Must use @niagaracollegetoronto.ca email"
      case "judge":
        return "You can use any personal email"
      default:
        return ""
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const newErrors: Record<string, string> = {}

    if (!formData.name) newErrors.name = "Name is required"
    if (!formData.email) {
      newErrors.email = "Email is required"
    } else if (!validateEmail(formData.email)) {
      newErrors.email = getEmailErrorMessage()
    }
    if (!formData.password) newErrors.password = "Password is required"
    if (formData.password.length < 8) newErrors.password = "Password must be at least 8 characters"
    if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = "Passwords do not match"
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors)
      return
    }

    setIsLoading(true)

    try {
      const users = JSON.parse(localStorage.getItem("users") || "[]")

      if (users.find((u: any) => u.email === formData.email)) {
        throw new Error("Email already registered")
      }

      const newUser = {
        id: Date.now(),
        email: formData.email,
        password: formData.password,
        name: formData.name,
        role: role,
      }

      users.push(newUser)
      localStorage.setItem("users", JSON.stringify(users))

      saveUser({ id: newUser.id, email: newUser.email, name: newUser.name, role: newUser.role })
      alert("Account created successfully!")

      if (role === "judge") {
        router.push("/judge-dashboard")
      } else if (role === "mentor") {
        router.push("/mentor-dashboard")
      } else {
        router.push("/team-register")
      }
    } catch (error: any) {
      console.error("[v0] Signup error:", error)
      alert(error.message || "Failed to create account")
    } finally {
      setIsLoading(false)
    }
  }

  const getRoleColor = () => {
    switch (role) {
      case "judge":
        return "from-purple-500 to-purple-600"
      case "mentor":
        return "from-pink-500 to-pink-600"
      default:
        return "from-cyan-500 to-cyan-600"
    }
  }

  const getRoleIcon = () => {
    switch (role) {
      case "judge":
        return (
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z"
          />
        )
      case "mentor":
        return (
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"
          />
        )
      default:
        return (
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"
          />
        )
    }
  }

  return (
    <div className="relative min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-purple-950 overflow-hidden">
      <FloatingShapes />

      <div className="relative z-10 flex min-h-screen items-center justify-center px-4 py-12">
        <div className="w-full max-w-md">
          <Link
            href="/role-select"
            className="inline-flex items-center gap-2 text-slate-400 hover:text-white transition-colors mb-8 animate-slide-in-left"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            Back to Role Selection
          </Link>

          <div className="neumorphic-card rounded-3xl p-8 space-y-8 animate-scale-in">
            <div className="text-center space-y-4">
              <div
                className={`w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br ${getRoleColor()} flex items-center justify-center glow-effect animate-bounce-in`}
              >
                <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  {getRoleIcon()}
                </svg>
              </div>
              <div className="animate-fade-in" style={{ animationDelay: "0.2s" }}>
                <h1 className="text-3xl font-bold text-white">Create Account</h1>
                <p className="text-slate-400 mt-2">Sign up as a {role}</p>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6 animate-slide-up" style={{ animationDelay: "0.3s" }}>
              <div className="space-y-2">
                <Label htmlFor="name" className="text-slate-300">
                  Full Name
                </Label>
                <Input
                  id="name"
                  type="text"
                  placeholder="John Doe"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500 focus:border-cyan-500"
                />
                {errors.name && <p className="text-sm text-red-400">{errors.name}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="email" className="text-slate-300">
                  Email Address
                </Label>
                <Input
                  id="email"
                  type="email"
                  placeholder={getEmailPlaceholder()}
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500 focus:border-cyan-500"
                />
                {errors.email && <p className="text-sm text-red-400">{errors.email}</p>}
                <p className="text-xs text-slate-500">{getEmailHelperText()}</p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="text-slate-300">
                  Password
                </Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500 focus:border-cyan-500"
                />
                {errors.password && <p className="text-sm text-red-400">{errors.password}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirmPassword" className="text-slate-300">
                  Confirm Password
                </Label>
                <Input
                  id="confirmPassword"
                  type="password"
                  placeholder="••••••••"
                  value={formData.confirmPassword}
                  onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                  className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500 focus:border-cyan-500"
                />
                {errors.confirmPassword && <p className="text-sm text-red-400">{errors.confirmPassword}</p>}
              </div>

              <Button
                type="submit"
                className={`w-full bg-gradient-to-r ${getRoleColor()} text-white font-semibold py-6 rounded-xl glow-effect-hover transition-all`}
                disabled={isLoading}
              >
                {isLoading ? "Creating Account..." : "Create Account"}
              </Button>
            </form>

            <div className="text-center animate-fade-in" style={{ animationDelay: "0.4s" }}>
              <p className="text-slate-400">
                Already have an account?{" "}
                <Link
                  href={`/signin?role=${role}`}
                  className="text-cyan-400 hover:text-cyan-300 font-semibold transition-colors"
                >
                  Sign In
                </Link>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default function SignUpPage() {
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <SignUpForm />
    </Suspense>
  )
}
