"use client"

import type React from "react"

import { useState, useRef } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { FloatingShapes } from "@/components/floating-shapes"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import { getCurrentUser, saveTeamData } from "@/lib/storage"

interface TeamMember {
  name: string
  studentId: string
  email: string
}

export default function TeamRegisterPage() {
  const router = useRouter()
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { toast } = useToast()
  const supabase = null // Placeholder for Supabase client, not used in this version

  const [formData, setFormData] = useState({
    leaderName: "",
    leaderStudentId: "",
    leaderEmail: "",
    teamName: "",
    teamDescription: "",
    logo: null as File | null,
  })

  const [teamMembers, setTeamMembers] = useState<TeamMember[]>([
    { name: "", studentId: "", email: "" },
    { name: "", studentId: "", email: "" },
  ])

  const [logoPreview, setLogoPreview] = useState<string | null>(null)
  const [errors, setErrors] = useState<Record<string, string>>({})

  const validateStudentEmail = (email: string) => {
    return email.endsWith("@nctorontostudents.ca")
  }

  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setFormData({ ...formData, logo: file })
      const reader = new FileReader()
      reader.onloadend = () => {
        setLogoPreview(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleMemberChange = (index: number, field: keyof TeamMember, value: string) => {
    const updatedMembers = [...teamMembers]
    updatedMembers[index][field] = value
    setTeamMembers(updatedMembers)
  }

  const addTeamMember = () => {
    if (teamMembers.length < 4) {
      setTeamMembers([...teamMembers, { name: "", studentId: "", email: "" }])
    }
  }

  const removeTeamMember = (index: number) => {
    if (teamMembers.length > 2) {
      const updatedMembers = teamMembers.filter((_, i) => i !== index)
      setTeamMembers(updatedMembers)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const newErrors: Record<string, string> = {}

    if (!formData.leaderStudentId) newErrors.leaderStudentId = "Student ID is required"
    if (!formData.leaderEmail) {
      newErrors.leaderEmail = "Email is required"
    } else if (!validateStudentEmail(formData.leaderEmail)) {
      newErrors.leaderEmail = "Email must be @nctorontostudents.ca"
    }
    if (!formData.leaderName) newErrors.leaderName = "Name is required"
    if (!formData.teamName) newErrors.teamName = "Team name is required"
    if (!formData.teamDescription) newErrors.teamDescription = "Team description is required"

    teamMembers.forEach((member, index) => {
      if (!member.name) newErrors[`member${index}Name`] = "Member name is required"
      if (!member.studentId) newErrors[`member${index}StudentId`] = "Member student ID is required"
      if (!member.email) {
        newErrors[`member${index}Email`] = "Member email is required"
      } else if (!validateStudentEmail(member.email)) {
        newErrors[`member${index}Email`] = "Email must be @nctorontostudents.ca"
      }
    })

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors)
      return
    }

    try {
      const user = getCurrentUser()
      if (!user) {
        toast({ title: "Error", description: "You must be logged in to create a team", variant: "destructive" })
        return
      }

      const group = {
        id: Date.now(),
        group_name: formData.teamName,
        leader_id: user.id,
      }

      const members = [
        {
          id: Date.now(),
          member_name: formData.leaderName,
          member_email: formData.leaderEmail,
          student_id: formData.leaderStudentId,
        },
        ...teamMembers.map((member, index) => ({
          id: Date.now() + index + 1,
          member_name: member.name,
          member_email: member.email,
          student_id: member.studentId,
        })),
      ]

      const project = {
        id: Date.now(),
        title: `${formData.teamName} Project`,
        description: formData.teamDescription,
        status: "in_progress",
        group_id: group.id,
      }

      saveTeamData(group, members, project)

      toast({ title: "Success!", description: "Team created successfully" })
      router.push("/dashboard")
    } catch (error) {
      console.error("[v0] Team registration error:", error)
      toast({ title: "Error", description: "Failed to create team", variant: "destructive" })
    }
  }

  return (
    <div className="relative min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-purple-950 overflow-hidden">
      <FloatingShapes />

      <div className="relative z-10 flex min-h-screen items-center justify-center px-4 py-12">
        <div className="w-full max-w-3xl">
          <Link
            href="/signup"
            className="inline-flex items-center gap-2 text-slate-400 hover:text-white transition-colors mb-8 animate-slide-in-left"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            Back
          </Link>

          <div className="neumorphic-card rounded-3xl p-8 space-y-8 animate-scale-in">
            <div className="text-center space-y-4">
              <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br from-cyan-500 to-purple-600 flex items-center justify-center glow-effect animate-bounce-in">
                <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"
                  />
                </svg>
              </div>
              <div className="animate-fade-in" style={{ animationDelay: "0.2s" }}>
                <h1 className="text-3xl font-bold text-white">Create Your Team</h1>
                <p className="text-slate-400 mt-2">Register your HackaPortal team (3-5 members)</p>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6 animate-slide-up" style={{ animationDelay: "0.3s" }}>
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                  <span className="w-8 h-8 rounded-full bg-gradient-to-r from-cyan-500 to-purple-600 flex items-center justify-center text-sm">
                    1
                  </span>
                  Team Information
                </h3>

                <div className="space-y-2">
                  <Label htmlFor="teamName" className="text-slate-300">
                    Team Name
                  </Label>
                  <Input
                    id="teamName"
                    type="text"
                    placeholder="Code Warriors"
                    value={formData.teamName}
                    onChange={(e) => setFormData({ ...formData, teamName: e.target.value })}
                    className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500 focus:border-cyan-500"
                  />
                  {errors.teamName && <p className="text-sm text-red-400">{errors.teamName}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="teamDescription" className="text-slate-300">
                    Team Description
                  </Label>
                  <Textarea
                    id="teamDescription"
                    placeholder="Tell us about your team and what you hope to build..."
                    value={formData.teamDescription}
                    onChange={(e) => setFormData({ ...formData, teamDescription: e.target.value })}
                    className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500 focus:border-cyan-500 min-h-24"
                  />
                  {errors.teamDescription && <p className="text-sm text-red-400">{errors.teamDescription}</p>}
                </div>

                <div className="space-y-2">
                  <Label className="text-slate-300">Team Logo</Label>
                  <div className="flex items-center gap-4">
                    {logoPreview ? (
                      <div className="relative w-24 h-24 rounded-xl overflow-hidden border-2 border-slate-700">
                        <img
                          src={logoPreview || "/placeholder.svg"}
                          alt="Team logo preview"
                          className="w-full h-full object-cover"
                        />
                        <button
                          type="button"
                          onClick={() => {
                            setLogoPreview(null)
                            setFormData({ ...formData, logo: null })
                            if (fileInputRef.current) fileInputRef.current.value = ""
                          }}
                          className="absolute top-1 right-1 w-6 h-6 bg-red-500 rounded-full flex items-center justify-center text-white hover:bg-red-600 transition-colors"
                        >
                          ×
                        </button>
                      </div>
                    ) : (
                      <div className="w-24 h-24 rounded-xl border-2 border-dashed border-slate-700 flex items-center justify-center">
                        <svg className="w-8 h-8 text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M7 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
                          />
                        </svg>
                      </div>
                    )}
                    <div className="flex-1">
                      <input
                        ref={fileInputRef}
                        type="file"
                        accept="image/*"
                        onChange={handleLogoChange}
                        className="hidden"
                        id="logo-upload"
                      />
                      <Label
                        htmlFor="logo-upload"
                        className="inline-flex items-center gap-2 px-4 py-2 bg-slate-800 text-slate-300 rounded-lg cursor-pointer hover:bg-slate-700 transition-colors"
                      >
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
                          />
                        </svg>
                        Upload Logo
                      </Label>
                      <p className="text-xs text-slate-500 mt-2">PNG, JPG up to 5MB</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-4 pt-4 border-t border-slate-700">
                <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                  <span className="w-8 h-8 rounded-full bg-gradient-to-r from-cyan-500 to-purple-600 flex items-center justify-center text-sm">
                    2
                  </span>
                  Team Leader Information
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="leaderStudentId" className="text-slate-300">
                      Student ID
                    </Label>
                    <Input
                      id="leaderStudentId"
                      type="text"
                      placeholder="12345678"
                      value={formData.leaderStudentId}
                      onChange={(e) => setFormData({ ...formData, leaderStudentId: e.target.value })}
                      className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500 focus:border-cyan-500"
                    />
                    {errors.leaderStudentId && <p className="text-sm text-red-400">{errors.leaderStudentId}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="leaderName" className="text-slate-300">
                      Full Name
                    </Label>
                    <Input
                      id="leaderName"
                      type="text"
                      placeholder="John Doe"
                      value={formData.leaderName}
                      onChange={(e) => setFormData({ ...formData, leaderName: e.target.value })}
                      className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500 focus:border-cyan-500"
                    />
                    {errors.leaderName && <p className="text-sm text-red-400">{errors.leaderName}</p>}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="leaderEmail" className="text-slate-300">
                    Email Address
                  </Label>
                  <Input
                    id="leaderEmail"
                    type="email"
                    placeholder="yourname@nctorontostudents.ca"
                    value={formData.leaderEmail}
                    onChange={(e) => setFormData({ ...formData, leaderEmail: e.target.value })}
                    className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500 focus:border-cyan-500"
                  />
                  {errors.leaderEmail && <p className="text-sm text-red-400">{errors.leaderEmail}</p>}
                  <p className="text-xs text-slate-500">Must use @nctorontostudents.ca email</p>
                </div>
              </div>

              <div className="space-y-4 pt-4 border-t border-slate-700">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                    <span className="w-8 h-8 rounded-full bg-gradient-to-r from-cyan-500 to-purple-600 flex items-center justify-center text-sm">
                      3
                    </span>
                    Team Members ({teamMembers.length + 1}/5)
                  </h3>
                  {teamMembers.length < 4 && (
                    <Button
                      type="button"
                      onClick={addTeamMember}
                      className="bg-slate-800 hover:bg-slate-700 text-slate-300"
                    >
                      + Add Member
                    </Button>
                  )}
                </div>
                <p className="text-sm text-slate-400">
                  Add 2-4 additional team members (minimum 3 total, maximum 5 total)
                </p>

                {teamMembers.map((member, index) => (
                  <div key={index} className="p-4 bg-slate-800/30 rounded-xl space-y-4 border border-slate-700">
                    <div className="flex items-center justify-between">
                      <h4 className="text-white font-medium">Member {index + 2}</h4>
                      {teamMembers.length > 2 && (
                        <button
                          type="button"
                          onClick={() => removeTeamMember(index)}
                          className="text-red-400 hover:text-red-300 text-sm"
                        >
                          Remove
                        </button>
                      )}
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor={`member${index}StudentId`} className="text-slate-300">
                          Student ID
                        </Label>
                        <Input
                          id={`member${index}StudentId`}
                          type="text"
                          placeholder="12345678"
                          value={member.studentId}
                          onChange={(e) => handleMemberChange(index, "studentId", e.target.value)}
                          className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500 focus:border-cyan-500"
                        />
                        {errors[`member${index}StudentId`] && (
                          <p className="text-sm text-red-400">{errors[`member${index}StudentId`]}</p>
                        )}
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor={`member${index}Name`} className="text-slate-300">
                          Full Name
                        </Label>
                        <Input
                          id={`member${index}Name`}
                          type="text"
                          placeholder="Jane Smith"
                          value={member.name}
                          onChange={(e) => handleMemberChange(index, "name", e.target.value)}
                          className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500 focus:border-cyan-500"
                        />
                        {errors[`member${index}Name`] && (
                          <p className="text-sm text-red-400">{errors[`member${index}Name`]}</p>
                        )}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor={`member${index}Email`} className="text-slate-300">
                        Email Address
                      </Label>
                      <Input
                        id={`member${index}Email`}
                        type="email"
                        placeholder="member@nctorontostudents.ca"
                        value={member.email}
                        onChange={(e) => handleMemberChange(index, "email", e.target.value)}
                        className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500 focus:border-cyan-500"
                      />
                      {errors[`member${index}Email`] && (
                        <p className="text-sm text-red-400">{errors[`member${index}Email`]}</p>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-cyan-500 to-purple-600 text-white font-semibold py-6 rounded-xl glow-effect-hover transition-all"
              >
                Create Team & Register
              </Button>
            </form>
          </div>
        </div>
      </div>
    </div>
  )
}
