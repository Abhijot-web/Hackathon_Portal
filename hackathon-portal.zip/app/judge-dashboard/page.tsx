"use client"

import { FloatingShapes } from "@/components/floating-shapes"
import { useState } from "react"

const mockSubmissions = [
  {
    id: 1,
    teamName: "Code Crusaders",
    leader: "Sarah Johnson",
    members: ["Sarah Johnson", "Mike Chen", "Emily Davis", "Alex Kumar"],
    mentor: "Dr. Smith",
    projectName: "AI-Powered Study Assistant",
    description: "An intelligent tutoring system that adapts to student learning patterns",
    submissionLink: "https://github.com/codecrusaders/ai-study",
    submittedAt: "2024-01-15",
    scores: null,
  },
  {
    id: 2,
    teamName: "Tech Titans",
    leader: "John Williams",
    members: ["John Williams", "Lisa Brown", "Tom Anderson"],
    mentor: "Prof. Johnson",
    projectName: "Smart Campus Navigator",
    description: "AR-based navigation system for campus buildings and facilities",
    submissionLink: "https://github.com/techtitans/campus-nav",
    submittedAt: "2024-01-15",
    scores: null,
  },
  {
    id: 3,
    teamName: "Innovation Squad",
    leader: "Maria Garcia",
    members: ["Maria Garcia", "David Lee", "Sophie Martin", "James Wilson", "Emma Taylor"],
    mentor: "Dr. Brown",
    projectName: "EcoTrack",
    description: "Carbon footprint tracking and sustainability recommendation platform",
    submissionLink: "https://github.com/innovationsquad/ecotrack",
    submittedAt: "2024-01-14",
    scores: null,
  },
]

const mockLeaderboard = [
  { rank: 1, teamName: "Code Crusaders", avgScore: 92, status: "Evaluated" },
  { rank: 2, teamName: "Tech Titans", avgScore: 88, status: "Evaluated" },
  { rank: 3, teamName: "Innovation Squad", avgScore: 85, status: "Pending" },
]

export default function JudgeDashboardPage() {
  const [selectedTeam, setSelectedTeam] = useState<number | null>(null)
  const [scores, setScores] = useState<{
    [key: number]: {
      innovation: string
      design: string
      functionality: string
      presentation: string
      comments: string
    }
  }>({})

  const handleScoreChange = (
    teamId: number,
    field: "innovation" | "design" | "functionality" | "presentation" | "comments",
    value: string,
  ) => {
    setScores((prev) => ({
      ...prev,
      [teamId]: {
        ...prev[teamId],
        [field]: value,
      },
    }))
  }

  const handleSubmitScore = (teamId: number) => {
    console.log("[v0] Submitting score for team:", teamId, scores[teamId])
    alert(`Score submitted for ${mockSubmissions.find((s) => s.id === teamId)?.teamName}`)
  }

  return (
    <div className="relative min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-purple-950 overflow-hidden">
      <FloatingShapes />

      <div className="relative z-10 min-h-screen px-4 py-8">
        {/* Header */}
        <div className="max-w-7xl mx-auto mb-8 animate-fade-in">
          <div className="flex items-center justify-between mb-2">
            <h1 className="text-4xl md:text-5xl font-bold gradient-text">Judge Dashboard</h1>
            <button className="px-4 py-2 rounded-xl bg-gradient-to-r from-purple-500 to-purple-600 text-white font-semibold glow-effect-hover transition-all duration-300 hover:scale-105">
              My Profile
            </button>
          </div>
          <p className="text-slate-400">Evaluate team submissions and provide feedback</p>
        </div>

        {/* Main Content */}
        <div className="max-w-7xl mx-auto space-y-6">
          {/* Stats Overview */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="neumorphic-card rounded-2xl p-6 animate-scale-in" style={{ animationDelay: "0.1s" }}>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 to-purple-600 flex items-center justify-center glow-effect">
                  <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                    />
                  </svg>
                </div>
                <div>
                  <p className="text-slate-400 text-sm">Total Submissions</p>
                  <p className="text-2xl font-bold text-white">{mockSubmissions.length}</p>
                </div>
              </div>
            </div>

            <div className="neumorphic-card rounded-2xl p-6 animate-scale-in" style={{ animationDelay: "0.2s" }}>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-500 to-cyan-600 flex items-center justify-center glow-effect">
                  <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                </div>
                <div>
                  <p className="text-slate-400 text-sm">Evaluated</p>
                  <p className="text-2xl font-bold text-white">0</p>
                </div>
              </div>
            </div>

            <div className="neumorphic-card rounded-2xl p-6 animate-scale-in" style={{ animationDelay: "0.3s" }}>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-pink-500 to-pink-600 flex items-center justify-center glow-effect">
                  <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                </div>
                <div>
                  <p className="text-slate-400 text-sm">Pending</p>
                  <p className="text-2xl font-bold text-white">{mockSubmissions.length}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Team Submissions */}
          <div className="neumorphic-card rounded-3xl p-8 animate-slide-up" style={{ animationDelay: "0.4s" }}>
            <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
              <svg className="w-6 h-6 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"
                />
              </svg>
              All Team Submissions
            </h2>

            <div className="space-y-4">
              {mockSubmissions.map((submission, index) => (
                <div
                  key={submission.id}
                  className="neumorphic-card rounded-2xl p-6 hover:scale-[1.02] transition-all duration-300 animate-fade-in"
                  style={{ animationDelay: `${0.5 + index * 0.1}s` }}
                >
                  <div className="flex flex-col lg:flex-row gap-6">
                    {/* Project Info */}
                    <div className="flex-1 space-y-3">
                      <div className="flex items-start justify-between">
                        <div>
                          <h3 className="text-xl font-bold text-white mb-1">{submission.projectName}</h3>
                          <p className="text-sm text-cyan-400 font-semibold">{submission.teamName}</p>
                        </div>
                        <span className="px-3 py-1 rounded-lg bg-purple-500/20 text-purple-400 text-xs font-semibold">
                          Pending Review
                        </span>
                      </div>
                      <div className="space-y-2 text-sm">
                        <div className="flex items-center gap-2 text-slate-300">
                          <svg className="w-4 h-4 text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={2}
                              d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
                            />
                          </svg>
                          <span>Leader: {submission.leader}</span>
                        </div>
                        <div className="flex items-center gap-2 text-slate-300">
                          <svg
                            className="w-4 h-4 text-purple-400"
                            fill="none"
                            stroke="currentColor"
                            viewBox="0 0 24 24"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={2}
                              d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"
                            />
                          </svg>
                          <span>Members: {submission.members.join(", ")}</span>
                        </div>
                        <div className="flex items-center gap-2 text-slate-300">
                          <svg className="w-4 h-4 text-pink-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={2}
                              d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"
                            />
                          </svg>
                          <span>Mentor: {submission.mentor}</span>
                        </div>
                      </div>
                      <p className="text-slate-300 leading-relaxed">{submission.description}</p>
                      <div className="flex items-center gap-4">
                        <div className="flex items-center gap-2 text-sm text-slate-400">
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={2}
                              d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                            />
                          </svg>
                          Submitted: {submission.submittedAt}
                        </div>
                        <a
                          href={submission.submissionLink}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-sm text-cyan-400 hover:text-cyan-300 underline"
                        >
                          View Project →
                        </a>
                      </div>
                    </div>

                    <div className="lg:w-96 space-y-4">
                      <h4 className="text-sm font-semibold text-slate-300 mb-3">Scoring Criteria (1-10)</h4>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block text-xs font-semibold text-slate-400 mb-1">Innovation</label>
                          <input
                            type="number"
                            min="1"
                            max="10"
                            placeholder="1-10"
                            value={scores[submission.id]?.innovation || ""}
                            onChange={(e) => handleScoreChange(submission.id, "innovation", e.target.value)}
                            className="w-full px-3 py-2 rounded-lg bg-slate-800/50 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-purple-500 transition-colors text-sm"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-400 mb-1">Design</label>
                          <input
                            type="number"
                            min="1"
                            max="10"
                            placeholder="1-10"
                            value={scores[submission.id]?.design || ""}
                            onChange={(e) => handleScoreChange(submission.id, "design", e.target.value)}
                            className="w-full px-3 py-2 rounded-lg bg-slate-800/50 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-purple-500 transition-colors text-sm"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-400 mb-1">Functionality</label>
                          <input
                            type="number"
                            min="1"
                            max="10"
                            placeholder="1-10"
                            value={scores[submission.id]?.functionality || ""}
                            onChange={(e) => handleScoreChange(submission.id, "functionality", e.target.value)}
                            className="w-full px-3 py-2 rounded-lg bg-slate-800/50 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-purple-500 transition-colors text-sm"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-400 mb-1">Presentation</label>
                          <input
                            type="number"
                            min="1"
                            max="10"
                            placeholder="1-10"
                            value={scores[submission.id]?.presentation || ""}
                            onChange={(e) => handleScoreChange(submission.id, "presentation", e.target.value)}
                            className="w-full px-3 py-2 rounded-lg bg-slate-800/50 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-purple-500 transition-colors text-sm"
                          />
                        </div>
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-slate-400 mb-1">Comments</label>
                        <textarea
                          rows={3}
                          placeholder="Provide detailed feedback..."
                          value={scores[submission.id]?.comments || ""}
                          onChange={(e) => handleScoreChange(submission.id, "comments", e.target.value)}
                          className="w-full px-3 py-2 rounded-lg bg-slate-800/50 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-purple-500 transition-colors resize-none text-sm"
                        />
                      </div>
                      <button
                        onClick={() => handleSubmitScore(submission.id)}
                        className="w-full px-4 py-3 rounded-xl bg-gradient-to-r from-purple-500 to-purple-600 text-white font-semibold glow-effect-hover transition-all duration-300 hover:scale-105"
                      >
                        Submit Score
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="neumorphic-card rounded-3xl p-8 animate-slide-up" style={{ animationDelay: "0.8s" }}>
            <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
              <svg className="w-6 h-6 text-yellow-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z"
                />
              </svg>
              Leaderboard
            </h2>

            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-slate-700">
                    <th className="text-left py-3 px-4 text-sm font-semibold text-slate-400">Rank</th>
                    <th className="text-left py-3 px-4 text-sm font-semibold text-slate-400">Team Name</th>
                    <th className="text-left py-3 px-4 text-sm font-semibold text-slate-400">Avg Score</th>
                    <th className="text-left py-3 px-4 text-sm font-semibold text-slate-400">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {mockLeaderboard.map((entry, index) => (
                    <tr
                      key={entry.rank}
                      className="border-b border-slate-800 hover:bg-slate-800/30 transition-colors animate-fade-in"
                      style={{ animationDelay: `${0.9 + index * 0.1}s` }}
                    >
                      <td className="py-4 px-4">
                        <div className="flex items-center gap-2">
                          {entry.rank === 1 && <span className="text-2xl">🥇</span>}
                          {entry.rank === 2 && <span className="text-2xl">🥈</span>}
                          {entry.rank === 3 && <span className="text-2xl">🥉</span>}
                          <span className="text-white font-semibold">#{entry.rank}</span>
                        </div>
                      </td>
                      <td className="py-4 px-4 text-white font-medium">{entry.teamName}</td>
                      <td className="py-4 px-4">
                        <span className="text-cyan-400 font-bold text-lg">{entry.avgScore}</span>
                      </td>
                      <td className="py-4 px-4">
                        <span
                          className={`px-3 py-1 rounded-lg text-xs font-semibold ${
                            entry.status === "Evaluated"
                              ? "bg-green-500/20 text-green-400"
                              : "bg-yellow-500/20 text-yellow-400"
                          }`}
                        >
                          {entry.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
