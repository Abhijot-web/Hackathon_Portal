"use client"

import type React from "react"

import { useState, Suspense } from "react"
import { useSearchParams, useRouter } from "next/navigation"
import Link from "next/link"
import { FloatingShapes } from "@/components/floating-shapes"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { saveUser } from "@/lib/storage"

function SignInForm() {
  const searchParams = useSearchParams()
  const router = useRouter()
  const role = searchParams.get("role") || "student"

  const [formData, setFormData] = useState({
    email: "",
    password: "",
    rememberMe: false,
  })
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [isLoading, setIsLoading] = useState(false)

  const validateEmail = (email: string) => {
    switch (role) {
      case "student":
        return email.endsWith("@nctorontostudents.ca")
      case "mentor":
        return email.endsWith("@niagaracollegetoronto.ca")
      case "judge":
        return email.includes("@") && email.includes(".")
      default:
        return false
    }
  }

  const getEmailErrorMessage = () => {
    switch (role) {
      case "student":
        return "Email must be @nctorontostudents.ca"
      case "mentor":
        return "Email must be @niagaracollegetoronto.ca"
      case "judge":
        return "Please enter a valid email address"
      default:
        return "Invalid email"
    }
  }

  const getEmailPlaceholder = () => {
    switch (role) {
      case "student":
        return "yourname@nctorontostudents.ca"
      case "mentor":
        return "yourname@niagaracollegetoronto.ca"
      case "judge":
        return "yourname@example.com"
      default:
        return "your.email@example.com"
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const newErrors: Record<string, string> = {}

    if (!formData.email) {
      newErrors.email = "Email is required"
    } else if (!validateEmail(formData.email)) {
      newErrors.email = getEmailErrorMessage()
    }
    if (!formData.password) newErrors.password = "Password is required"

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors)
      return
    }

    setIsLoading(true)

    try {
      const users = JSON.parse(localStorage.getItem("users") || "[]")
      console.log("[v0] Total users in database:", users.length)
      console.log("[v0] Attempting signin with email:", formData.email)
      console.log("[v0] Attempting signin with role:", role)

      const user = users.find((u: any) => u.email === formData.email && u.password === formData.password)
      console.log("[v0] User found:", user ? "Yes" : "No")

      if (!user) {
        const emailExists = users.find((u: any) => u.email === formData.email)
        if (emailExists) {
          console.log("[v0] Email exists but password is incorrect")
          throw new Error("Invalid password")
        } else {
          console.log("[v0] Email not found in database")
          throw new Error("Email not registered. Please sign up first.")
        }
      }

      if (user.role !== role) {
        console.log("[v0] Role mismatch - user is:", user.role, "trying to access:", role)
        throw new Error(`This account is registered as a ${user.role}, not a ${role}`)
      }

      console.log("[v0] Signin successful for user:", user.name)
      saveUser({ id: user.id, email: user.email, name: user.name, role: user.role })
      alert("Signed in successfully!")

      if (role === "judge") {
        router.push("/judge-dashboard")
      } else if (role === "mentor") {
        router.push("/mentor-dashboard")
      } else {
        router.push("/dashboard")
      }
    } catch (error: any) {
      console.error("[v0] Signin error:", error.message)
      alert(error.message || "Failed to sign in")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="relative min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-purple-950 overflow-hidden">
      <FloatingShapes />

      <div className="relative z-10 flex min-h-screen items-center justify-center px-4 py-12">
        <div className="w-full max-w-md">
          <Link
            href="/role-select"
            className="inline-flex items-center gap-2 text-slate-400 hover:text-white transition-colors mb-8 animate-slide-in-left"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            Back to Role Selection
          </Link>

          <div className="neumorphic-card rounded-3xl p-8 space-y-8 animate-scale-in">
            <div className="text-center space-y-4">
              <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br from-cyan-500 to-purple-600 flex items-center justify-center glow-effect animate-bounce-in">
                <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1"
                  />
                </svg>
              </div>
              <div className="animate-fade-in" style={{ animationDelay: "0.2s" }}>
                <h1 className="text-3xl font-bold text-white">Welcome Back</h1>
                <p className="text-slate-400 mt-2">Sign in to your account</p>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6 animate-slide-up" style={{ animationDelay: "0.3s" }}>
              <div className="space-y-2">
                <Label htmlFor="email" className="text-slate-300">
                  Email Address
                </Label>
                <Input
                  id="email"
                  type="email"
                  placeholder={getEmailPlaceholder()}
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500 focus:border-cyan-500"
                />
                {errors.email && <p className="text-sm text-red-400">{errors.email}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="text-slate-300">
                  Password
                </Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500 focus:border-cyan-500"
                />
                {errors.password && <p className="text-sm text-red-400">{errors.password}</p>}
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Checkbox
                    id="remember"
                    checked={formData.rememberMe}
                    onCheckedChange={(checked) => setFormData({ ...formData, rememberMe: checked as boolean })}
                    className="border-slate-600"
                  />
                  <Label htmlFor="remember" className="text-sm text-slate-400 cursor-pointer">
                    Remember me
                  </Label>
                </div>
                <Link href="/forgot-password" className="text-sm text-cyan-400 hover:text-cyan-300 transition-colors">
                  Forgot Password?
                </Link>
              </div>

              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-cyan-500 to-purple-600 text-white font-semibold py-6 rounded-xl glow-effect-hover transition-all"
                disabled={isLoading}
              >
                {isLoading ? "Signing In..." : "Sign In"}
              </Button>
            </form>

            <div className="text-center animate-fade-in" style={{ animationDelay: "0.4s" }}>
              <p className="text-slate-400">
                Don't have an account?{" "}
                <Link href="/role-select" className="text-cyan-400 hover:text-cyan-300 font-semibold transition-colors">
                  Sign Up
                </Link>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default function SignInPage() {
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <SignInForm />
    </Suspense>
  )
}
