"use client"

import { FloatingShapes } from "@/components/floating-shapes"
import { useState } from "react"

// Mock data for assigned teams
const mockAssignedTeams = [
  {
    id: 1,
    teamName: "Code Crusaders",
    leader: "Sarah Johnson",
    members: ["Sarah Johnson", "Mike Chen", "Emily Davis", "Alex Kumar"],
    projectName: "AI-Powered Study Assistant",
    projectDescription:
      "An intelligent tutoring system that adapts to student learning patterns using machine learning algorithms. The system analyzes student performance and provides personalized recommendations.",
    submissionLink: "https://github.com/codecrusaders/ai-study",
    lastContact: "2 hours ago",
    status: "active",
  },
  {
    id: 2,
    teamName: "Tech Titans",
    leader: "John Williams",
    members: ["John Williams", "Lisa Brown", "Tom Anderson"],
    projectName: "Smart Campus Navigator",
    projectDescription:
      "AR-based navigation system for campus buildings and facilities. Uses augmented reality to help students and visitors find their way around campus with real-time directions.",
    submissionLink: "https://github.com/techtitans/campus-nav",
    lastContact: "1 day ago",
    status: "active",
  },
  {
    id: 3,
    teamName: "Innovation Squad",
    leader: "Maria Garcia",
    members: ["Maria Garcia", "David Lee", "Sophie Martin", "James Wilson", "Emma Taylor"],
    projectName: "EcoTrack",
    projectDescription:
      "Carbon footprint tracking and sustainability recommendation platform. Helps users monitor their environmental impact and provides actionable suggestions for reducing carbon emissions.",
    submissionLink: "https://github.com/innovationsquad/ecotrack",
    lastContact: "3 days ago",
    status: "needs-attention",
  },
]

// Mock queries from teams
const mockQueries = [
  {
    id: 1,
    teamName: "Code Crusaders",
    message: "We're having trouble integrating the AI model. Can you help us with the API setup?",
    timestamp: "2 hours ago",
    status: "unread",
  },
  {
    id: 2,
    teamName: "Tech Titans",
    message: "Could you review our project architecture before we proceed with development?",
    timestamp: "5 hours ago",
    status: "unread",
  },
]

export default function MentorDashboardPage() {
  const [selectedTeam, setSelectedTeam] = useState<number | null>(null)
  const [replyMessage, setReplyMessage] = useState("")
  const [feedback, setFeedback] = useState<{ [key: number]: string }>({})

  const handleSendReply = (queryId: number) => {
    console.log("[v0] Sending reply to query:", queryId, replyMessage)
    alert("Reply sent successfully!")
    setReplyMessage("")
  }

  const handleSaveFeedback = (teamId: number) => {
    console.log("[v0] Saving feedback for team:", teamId, feedback[teamId])
    alert(`Feedback saved for ${mockAssignedTeams.find((t) => t.id === teamId)?.teamName}`)
    setSelectedTeam(null)
  }

  const selectedTeamData = mockAssignedTeams.find((t) => t.id === selectedTeam)

  return (
    <div className="relative min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-purple-950 overflow-hidden">
      <FloatingShapes />

      <div className="relative z-10 min-h-screen px-4 py-8">
        {/* Header */}
        <div className="max-w-7xl mx-auto mb-8 animate-fade-in">
          <div className="flex items-center justify-between mb-2">
            <h1 className="text-4xl md:text-5xl font-bold gradient-text">Mentor Dashboard</h1>
            <button className="px-4 py-2 rounded-xl bg-gradient-to-r from-pink-500 to-pink-600 text-white font-semibold glow-effect-hover transition-all duration-300 hover:scale-105">
              My Profile
            </button>
          </div>
          <p className="text-slate-400">Guide and support your assigned teams</p>
        </div>

        {/* Main Content */}
        <div className="max-w-7xl mx-auto space-y-6">
          {/* Stats Overview */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="neumorphic-card rounded-2xl p-6 animate-scale-in" style={{ animationDelay: "0.1s" }}>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-pink-500 to-pink-600 flex items-center justify-center glow-effect">
                  <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"
                    />
                  </svg>
                </div>
                <div>
                  <p className="text-slate-400 text-sm">Assigned Teams</p>
                  <p className="text-2xl font-bold text-white">{mockAssignedTeams.length}</p>
                </div>
              </div>
            </div>

            <div className="neumorphic-card rounded-2xl p-6 animate-scale-in" style={{ animationDelay: "0.2s" }}>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-500 to-cyan-600 flex items-center justify-center glow-effect">
                  <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"
                    />
                  </svg>
                </div>
                <div>
                  <p className="text-slate-400 text-sm">Pending Queries</p>
                  <p className="text-2xl font-bold text-white">{mockQueries.length}</p>
                </div>
              </div>
            </div>

            <div className="neumorphic-card rounded-2xl p-6 animate-scale-in" style={{ animationDelay: "0.3s" }}>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 to-purple-600 flex items-center justify-center glow-effect">
                  <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                </div>
                <div>
                  <p className="text-slate-400 text-sm">Active Teams</p>
                  <p className="text-2xl font-bold text-white">
                    {mockAssignedTeams.filter((t) => t.status === "active").length}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Assigned Teams */}
          <div className="neumorphic-card rounded-3xl p-8 animate-slide-up" style={{ animationDelay: "0.4s" }}>
            <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
              <svg className="w-6 h-6 text-pink-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"
                />
              </svg>
              Assigned Teams
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {mockAssignedTeams.map((team, index) => (
                <div
                  key={team.id}
                  className="neumorphic-card rounded-2xl p-6 hover:scale-105 transition-all duration-300 animate-scale-in"
                  style={{ animationDelay: `${0.5 + index * 0.1}s` }}
                >
                  <div className="space-y-4">
                    <div className="flex items-start justify-between">
                      <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-pink-500 to-purple-600 flex items-center justify-center text-xl font-bold text-white glow-effect">
                        {team.teamName.charAt(0)}
                      </div>
                      <span
                        className={`px-2 py-1 rounded-lg text-xs font-semibold ${
                          team.status === "active"
                            ? "bg-green-500/20 text-green-400"
                            : "bg-yellow-500/20 text-yellow-400"
                        }`}
                      >
                        {team.status === "active" ? "Active" : "Needs Attention"}
                      </span>
                    </div>

                    <div>
                      <h3 className="text-lg font-bold text-white mb-1">{team.teamName}</h3>
                      <p className="text-sm text-slate-400">{team.projectName}</p>
                    </div>

                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2 text-slate-300">
                        <svg className="w-4 h-4 text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
                          />
                        </svg>
                        <span>Leader: {team.leader}</span>
                      </div>
                      <div className="flex items-center gap-2 text-slate-300">
                        <svg className="w-4 h-4 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"
                          />
                        </svg>
                        <span>{team.members.length} members</span>
                      </div>
                      <div className="flex items-center gap-2 text-slate-300">
                        <svg className="w-4 h-4 text-pink-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                          />
                        </svg>
                        <span>Last contact: {team.lastContact}</span>
                      </div>
                    </div>

                    <button
                      onClick={() => setSelectedTeam(team.id)}
                      className="w-full px-4 py-2 rounded-xl bg-gradient-to-r from-pink-500/20 to-purple-600/20 border border-pink-500/30 text-pink-400 font-semibold hover:scale-105 transition-all duration-300"
                    >
                      View Details
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Team Queries */}
          <div className="neumorphic-card rounded-3xl p-8 animate-slide-up" style={{ animationDelay: "0.8s" }}>
            <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
              <svg className="w-6 h-6 text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"
                />
              </svg>
              Team Queries
            </h2>

            <div className="space-y-4">
              {mockQueries.map((query, index) => (
                <div
                  key={query.id}
                  className="neumorphic-card rounded-2xl p-6 animate-fade-in"
                  style={{ animationDelay: `${0.9 + index * 0.1}s` }}
                >
                  <div className="space-y-4">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="text-lg font-bold text-white mb-1">{query.teamName}</h3>
                        <p className="text-sm text-slate-400">{query.timestamp}</p>
                      </div>
                      <span className="px-3 py-1 rounded-lg bg-cyan-500/20 text-cyan-400 text-xs font-semibold">
                        New
                      </span>
                    </div>

                    <p className="text-slate-300 leading-relaxed">{query.message}</p>

                    <div className="space-y-3">
                      <textarea
                        rows={3}
                        placeholder="Type your response..."
                        value={replyMessage}
                        onChange={(e) => setReplyMessage(e.target.value)}
                        className="w-full px-4 py-3 rounded-xl bg-slate-800/50 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition-colors resize-none"
                      />
                      <button
                        onClick={() => handleSendReply(query.id)}
                        className="px-6 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-cyan-600 text-white font-semibold glow-effect-hover transition-all duration-300 hover:scale-105"
                      >
                        Send Reply
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Project Details Modal */}
      {selectedTeam && selectedTeamData && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fade-in">
          <div className="neumorphic-card rounded-3xl p-8 max-w-3xl w-full max-h-[90vh] overflow-y-auto animate-scale-in">
            <div className="flex items-start justify-between mb-6">
              <div>
                <h2 className="text-3xl font-bold text-white mb-2">{selectedTeamData.teamName}</h2>
                <p className="text-cyan-400 font-semibold">{selectedTeamData.projectName}</p>
              </div>
              <button
                onClick={() => setSelectedTeam(null)}
                className="w-10 h-10 rounded-xl bg-slate-800/50 hover:bg-slate-700/50 flex items-center justify-center transition-colors"
              >
                <svg className="w-6 h-6 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            <div className="space-y-6">
              {/* Team Info */}
              <div className="space-y-3">
                <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                  <svg className="w-5 h-5 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"
                    />
                  </svg>
                  Team Members
                </h3>
                <div className="flex flex-wrap gap-2">
                  {selectedTeamData.members.map((member, idx) => (
                    <span
                      key={idx}
                      className="px-3 py-1 rounded-lg bg-purple-500/20 text-purple-300 text-sm font-medium"
                    >
                      {member}
                      {member === selectedTeamData.leader && " (Leader)"}
                    </span>
                  ))}
                </div>
              </div>

              {/* Project Description */}
              <div className="space-y-3">
                <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                  <svg className="w-5 h-5 text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                    />
                  </svg>
                  Project Description
                </h3>
                <p className="text-slate-300 leading-relaxed">{selectedTeamData.projectDescription}</p>
                <a
                  href={selectedTeamData.submissionLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-cyan-400 hover:text-cyan-300 font-medium"
                >
                  View Submission
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"
                    />
                  </svg>
                </a>
              </div>

              {/* Feedback Section */}
              <div className="space-y-3">
                <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                  <svg className="w-5 h-5 text-pink-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M7 8h10M7 12h4m1 8l-4-4H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-3l-4 4z"
                    />
                  </svg>
                  Leave Feedback
                </h3>
                <textarea
                  rows={5}
                  placeholder="Provide guidance and feedback for the team..."
                  value={feedback[selectedTeam] || ""}
                  onChange={(e) => setFeedback({ ...feedback, [selectedTeam]: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl bg-slate-800/50 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-pink-500 transition-colors resize-none"
                />
                <button
                  onClick={() => handleSaveFeedback(selectedTeam)}
                  className="w-full px-6 py-3 rounded-xl bg-gradient-to-r from-pink-500 to-pink-600 text-white font-semibold glow-effect-hover transition-all duration-300 hover:scale-105"
                >
                  Save Feedback
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
