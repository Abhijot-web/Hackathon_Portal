"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { FloatingShapes } from "@/components/floating-shapes"

export default function LoadingPage() {
  const router = useRouter()
  const [progress, setProgress] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setTimeout(() => {
            router.push("/role-select")
          }, 500)
          return 100
        }
        return prev + 2
      })
    }, 50)

    return () => clearInterval(interval)
  }, [router])

  return (
    <div className="relative min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-purple-950 overflow-hidden">
      <FloatingShapes />

      <div className="relative z-10 flex min-h-screen flex-col items-center justify-center px-4">
        <div className="text-center space-y-12 max-w-md">
          {/* Loading Icon */}
          <div className="relative w-32 h-32 mx-auto">
            <div className="absolute inset-0 rounded-full border-4 border-slate-700"></div>
            <div
              className="absolute inset-0 rounded-full border-4 border-transparent border-t-cyan-500 border-r-purple-600 pulse-glow animate-spin"
              style={{ animationDuration: "1s" }}
            ></div>
            <div className="absolute inset-4 rounded-full bg-gradient-to-br from-cyan-500/20 to-purple-600/20 flex items-center justify-center">
              <svg className="w-12 h-12 text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </div>
          </div>

          {/* Loading Text */}
          <div className="space-y-4">
            <h2 className="text-3xl font-bold gradient-text">Initializing Portal</h2>
            <p className="text-slate-400">Preparing your HackaPortal experience...</p>
          </div>

          {/* Progress Bar */}
          <div className="w-full space-y-2">
            <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-cyan-500 to-purple-600 transition-all duration-300 ease-out"
                style={{ width: `${progress}%` }}
              ></div>
            </div>
            <p className="text-sm text-slate-500 text-center">{progress}%</p>
          </div>
        </div>
      </div>
    </div>
  )
}
