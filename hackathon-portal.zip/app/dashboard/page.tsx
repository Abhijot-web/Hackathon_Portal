"use client"

import { FloatingShapes } from "@/components/floating-shapes"
import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { getCurrentUser, getTeamData } from "@/lib/storage"

interface Member {
  id: number
  member_name: string
  member_email: string
}

interface Group {
  id: number
  group_name: string
  leader_id: number
}

interface Project {
  id: number
  title: string
  description: string
  status: string
}

export default function DashboardPage() {
  const [activeTab, setActiveTab] = useState<"overview" | "members">("overview")
  const [group, setGroup] = useState<any>(null)
  const [members, setMembers] = useState<any[]>([])
  const [project, setProject] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    const user = getCurrentUser()
    if (!user) {
      router.push("/signin")
      return
    }

    const teamData = getTeamData()
    if (!teamData) {
      setLoading(false)
      return
    }

    setGroup(teamData.group)
    setMembers(teamData.members)
    setProject(teamData.project)
    setLoading(false)
  }, [router])

  if (loading) {
    return (
      <div className="relative min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-purple-950 overflow-hidden flex items-center justify-center">
        <FloatingShapes />
        <div className="text-white text-xl">Loading team data...</div>
      </div>
    )
  }

  if (!group) {
    return (
      <div className="relative min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-purple-950 overflow-hidden flex items-center justify-center">
        <FloatingShapes />
        <div className="text-center space-y-4">
          <div className="text-white text-xl">No team found</div>
          <Button
            onClick={() => router.push("/team-register")}
            className="bg-gradient-to-r from-cyan-500 to-purple-600"
          >
            Create Team
          </Button>
        </div>
      </div>
    )
  }

  const leader = members[0] || { member_name: "Unknown", member_email: "" }
  const teamMembers = members.slice(1)

  return (
    <div className="relative min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-purple-950 overflow-hidden">
      <FloatingShapes />

      <div className="relative z-10 min-h-screen px-4 py-8">
        {/* Header */}
        <div className="max-w-7xl mx-auto mb-8 animate-fade-in">
          <div className="flex items-center justify-between mb-2">
            <h1 className="text-4xl md:text-5xl font-bold gradient-text">Student Portal</h1>
            <button className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-purple-600 text-white font-semibold glow-effect-hover transition-all duration-300 hover:scale-105">
              Edit Profile
            </button>
          </div>
          <p className="text-slate-400">Welcome back! Here's your team overview</p>
        </div>

        {/* Main Content */}
        <div className="max-w-7xl mx-auto space-y-6">
          {/* Team Overview Card */}
          <div className="neumorphic-card rounded-3xl p-8 animate-slide-up" style={{ animationDelay: "0.1s" }}>
            <div className="flex flex-col md:flex-row gap-8 items-start">
              {/* Team Logo */}
              <div className="flex-shrink-0 animate-scale-in" style={{ animationDelay: "0.2s" }}>
                <div className="relative w-32 h-32 rounded-2xl overflow-hidden glow-effect bg-gradient-to-br from-cyan-500 to-purple-600 flex items-center justify-center text-4xl font-bold text-white">
                  {group.group_name.charAt(0)}
                </div>
              </div>

              {/* Team Info */}
              <div className="flex-1 space-y-4 animate-fade-in" style={{ animationDelay: "0.3s" }}>
                <div>
                  <h2 className="text-3xl font-bold text-white mb-2">{group.group_name}</h2>
                  <div className="flex items-center gap-2 text-sm text-slate-400">
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"
                      />
                    </svg>
                    <span>{members.length} Members</span>
                  </div>
                </div>
                <p className="text-slate-300 leading-relaxed">{project?.description || "No project description yet"}</p>

                {/* Team Leader Badge */}
                <div className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500/20 to-purple-600/20 border border-cyan-500/30">
                  <svg className="w-5 h-5 text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z"
                    />
                  </svg>
                  <span className="text-sm font-semibold text-white">Leader: {leader.member_name}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Tabs */}
          <div className="flex gap-4 animate-slide-up" style={{ animationDelay: "0.4s" }}>
            <button
              onClick={() => setActiveTab("overview")}
              className={`px-6 py-3 rounded-xl font-semibold transition-all duration-300 ${
                activeTab === "overview"
                  ? "bg-gradient-to-r from-cyan-500 to-purple-600 text-white glow-effect"
                  : "bg-slate-800/50 text-slate-400 hover:bg-slate-800 hover:text-white"
              }`}
            >
              Team Overview
            </button>
            <button
              onClick={() => setActiveTab("members")}
              className={`px-6 py-3 rounded-xl font-semibold transition-all duration-300 ${
                activeTab === "members"
                  ? "bg-gradient-to-r from-cyan-500 to-purple-600 text-white glow-effect"
                  : "bg-slate-800/50 text-slate-400 hover:bg-slate-800 hover:text-white"
              }`}
            >
              All Members
            </button>
          </div>

          {/* Tab Content */}
          {activeTab === "overview" && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Team Stats */}
              <div
                className="neumorphic-card rounded-2xl p-6 space-y-4 animate-scale-in"
                style={{ animationDelay: "0.5s" }}
              >
                <h3 className="text-xl font-bold text-white flex items-center gap-2">
                  <svg className="w-6 h-6 text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"
                    />
                  </svg>
                  Team Statistics
                </h3>
                <div className="space-y-3">
                  <div className="flex justify-between items-center p-3 rounded-xl bg-slate-800/50">
                    <span className="text-slate-400">Total Members</span>
                    <span className="text-2xl font-bold gradient-text">{members.length}</span>
                  </div>
                  <div className="flex justify-between items-center p-3 rounded-xl bg-slate-800/50">
                    <span className="text-slate-400">Project Status</span>
                    <span className="text-lg font-semibold text-white capitalize">{project?.status || "N/A"}</span>
                  </div>
                  <div className="flex justify-between items-center p-3 rounded-xl bg-slate-800/50">
                    <span className="text-slate-400">Team Members</span>
                    <span className="text-lg font-semibold text-white">{teamMembers.length}</span>
                  </div>
                </div>
              </div>

              {/* Quick Actions */}
              <div
                className="neumorphic-card rounded-2xl p-6 space-y-4 animate-scale-in"
                style={{ animationDelay: "0.6s" }}
              >
                <h3 className="text-xl font-bold text-white flex items-center gap-2">
                  <svg className="w-6 h-6 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                  Quick Actions
                </h3>
                <div className="space-y-3">
                  <button className="w-full p-4 rounded-xl bg-gradient-to-r from-cyan-500/10 to-cyan-600/10 border border-cyan-500/30 text-left hover:scale-105 transition-all duration-300 group">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-cyan-500/20 flex items-center justify-center group-hover:bg-cyan-500/30 transition-colors">
                        <svg className="w-5 h-5 text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                          />
                        </svg>
                      </div>
                      <div>
                        <p className="font-semibold text-white">Submit Project</p>
                        <p className="text-sm text-slate-400">Upload your HackaPortal project</p>
                      </div>
                    </div>
                  </button>
                  <button className="w-full p-4 rounded-xl bg-gradient-to-r from-purple-500/10 to-purple-600/10 border border-purple-500/30 text-left hover:scale-105 transition-all duration-300 group">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center group-hover:bg-purple-500/30 transition-colors">
                        <svg className="w-5 h-5 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"
                          />
                        </svg>
                      </div>
                      <div>
                        <p className="font-semibold text-white">Team Chat</p>
                        <p className="text-sm text-slate-400">Communicate with your team</p>
                      </div>
                    </div>
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === "members" && (
            <div className="space-y-4">
              {/* Team Leader Card */}
              <div
                className="neumorphic-card rounded-2xl p-6 animate-slide-up border-2 border-cyan-500/30"
                style={{ animationDelay: "0.5s" }}
              >
                <div className="flex items-start gap-4">
                  <div className="flex-shrink-0">
                    <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-cyan-500 to-purple-600 flex items-center justify-center text-2xl font-bold text-white glow-effect">
                      {leader.member_name.charAt(0)}
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h4 className="text-xl font-bold text-white">{leader.member_name}</h4>
                      <span className="px-3 py-1 rounded-lg bg-gradient-to-r from-cyan-500 to-purple-600 text-xs font-bold text-white glow-effect">
                        TEAM LEADER
                      </span>
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-slate-300">
                        <svg className="w-4 h-4 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                          />
                        </svg>
                        <span className="text-sm">{leader.member_email}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Team Members Cards */}
              {teamMembers.map((member, index) => (
                <div
                  key={member.id}
                  className="neumorphic-card rounded-2xl p-6 animate-slide-up hover:scale-[1.02] transition-all duration-300"
                  style={{ animationDelay: `${0.6 + index * 0.1}s` }}
                >
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0">
                      <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-slate-700 to-slate-600 flex items-center justify-center text-2xl font-bold text-white">
                        {member.member_name.charAt(0)}
                      </div>
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h4 className="text-xl font-bold text-white">{member.member_name}</h4>
                        <span className="px-3 py-1 rounded-lg bg-slate-700/50 text-xs font-semibold text-slate-300">
                          MEMBER
                        </span>
                      </div>
                      <div className="space-y-2">
                        <div className="flex items-center gap-2 text-slate-300">
                          <svg
                            className="w-4 h-4 text-purple-400"
                            fill="none"
                            stroke="currentColor"
                            viewBox="0 0 24 24"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={2}
                              d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 012 2z"
                            />
                          </svg>
                          <span className="text-sm">{member.member_email}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
